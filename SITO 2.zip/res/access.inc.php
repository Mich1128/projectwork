<?php

// Users data
$imSettings['access']['users'] = array(
	'admin' => array(
		'groups' => array('920x679d'),
		'id' => '920x679d',
		'name' => 'Admin',
		'password' => '61ouss55',
		'page' => 'index.html'
	),
	'nuovoutente' => array(
		'groups' => array('6rb95f3d'),
		'id' => '6rb95f3d',
		'name' => 'NuovoUtente',
		'password' => 'pjm306l7',
		'page' => 'index.html'
	)
);

// Admins list
$imSettings['access']['admins'] = array('920x679d');

// Page/Users permissions
$imSettings['access']['pages'] = array();

// End of file access.inc.php